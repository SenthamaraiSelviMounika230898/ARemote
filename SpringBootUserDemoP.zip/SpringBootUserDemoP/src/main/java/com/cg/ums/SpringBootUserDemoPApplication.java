package com.cg.ums;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUserDemoPApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUserDemoPApplication.class, args);
	}

}
